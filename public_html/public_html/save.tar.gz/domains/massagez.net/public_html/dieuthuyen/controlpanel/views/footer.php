<?php defined("WEB_APP") or die("Please wait ... <META http-equiv=\"refresh\" content=\"0; url=".WEBSITE_URL."\" />");?>

                </div> <!-- end class page-content -->
            </div> <!-- end class main-content -->
        </div> <!-- end class main-container-inner -->
    </div> <!-- end class main-container -->
</div> <!-- end class container -->
<div id="fb-root"></div>
</body>
</html>