<?php defined("WEB_APP") or die("Please wait ... <META http-equiv=\"refresh\" content=\"0; url=".WEBSITE_URL."\" />");?>
<div class="container">
    <div class="page-content">
        <div>
            <img style="max-width: 49%; height: 210px;" src="<?=WEBSITE_URL;?>/banner/<?=$officeid;?>/header-massage.png" />
            <img style="max-width: 49%; height: 210px;" src="<?=WEBSITE_URL;?>/banner/<?=$officeid;?>/header-<?=$officeitem["subdomain"];?>.png" />
        </div>