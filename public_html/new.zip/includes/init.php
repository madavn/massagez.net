<?php
    require_once INCLUDES."config.php";
    require_once INCLUDES."database.php";
    require_once INCLUDES."functions.php";
    require_once INCLUDES."request.php";
?>