<?php defined("WEB_APP") or die("Please wait ... <META http-equiv=\"refresh\" content=\"0; url=".WEBSITE_URL."\" />");?>
    </div> <!-- end page-content -->
</div> <!-- end container -->
</body>
</html>