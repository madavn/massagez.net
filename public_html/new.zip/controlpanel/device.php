<?php
    defined("WEB_APP") or die("Please wait ... <META http-equiv=\"refresh\" content=\"0; url=".WEBSITE_URL."\" />");
    define("VIEWS",BASE_URL."/controlpanel/views/"); // views for pc
    define("VIEWS_FOLDER","/controlpanel/views/");
?>